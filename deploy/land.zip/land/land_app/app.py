# -*- coding: utf-8 -*-
"""
土地估值模型 - 本地网站后端
输入省份/城市/区县/土地类型/面积/容积率/土地等级等参数，预测成交总价。

运行:  python app.py
访问:  http://127.0.0.1:5000
"""
import os
import json
import sys
import numpy as np
import joblib
from flask import Flask, render_template, request, jsonify

# 路径（相对 land_app/ 目录）
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PKL = os.path.join(BASE_DIR, "..", "models", "land_price_predictor.pkl")
OPTIONS = os.path.join(BASE_DIR, "options.json")

app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False
app.config["TEMPLATES_AUTO_RELOAD"] = True  # 修改模板后自动生效，无需重启

# 全局加载预测器与选项
_PREDICTOR = joblib.load(PKL)
_MODEL = _PREDICTOR["model"]
_ENCODERS = _PREDICTOR["encoders"]
_NUM_FEATS = _PREDICTOR["num_feats"]
_CAT_FEATS = _PREDICTOR["cat_feats"]

with open(OPTIONS, "r", encoding="utf-8") as f:
    _OPTIONS = json.load(f)


def predict_price(province, city, district, land_type, area, far, far_hi,
                  land_level, years, supply, source, industry):
    """核心预测逻辑（与笔记本 predict_price 一致）。"""
    if far_hi is None or far_hi == "":
        far_hi = far
    area = float(area)
    row_num = {
        "面积(m2)": area,
        "土地使用年限": float(years),
        "约定容积率下限": float(far),
        "约定容积率上限": float(far_hi),
    }
    row_cat = {
        "所在省份": str(province),
        "所在城市": str(city),
        "所在区县": str(district) if district else "缺失",
        "土地用途": str(land_type),
        "土地来源_简化": str(source),
        "供地方式": str(supply),
        "土地级别": str(land_level),
        "行业分类": str(industry) if industry else "其他",
    }
    enc_cat = [
        _ENCODERS[c]["mapping"].get(row_cat[c], _ENCODERS[c]["default"])
        for c in _CAT_FEATS
    ]
    feat = np.array(
        [row_num[c] for c in _NUM_FEATS] + enc_cat, dtype=float
    ).reshape(1, -1)
    total = float(np.expm1(_MODEL.predict(feat)[0]))
    unit = total / area if area > 0 else 0.0
    return total, unit


@app.route("/")
def index():
    return render_template("index.html", options=json.dumps(_OPTIONS, ensure_ascii=False))


@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json(force=True)
    try:
        total, unit = predict_price(
            province=data.get("省份", ""),
            city=data.get("城市", ""),
            district=data.get("区县", ""),
            land_type=data.get("土地类型", ""),
            area=data.get("面积", 10000),
            far=data.get("容积率", 1.0),
            far_hi=data.get("容积率上限", None),
            land_level=data.get("土地级别", "四级"),
            years=data.get("年限", 50),
            supply=data.get("供地方式", "挂牌出让"),
            source=data.get("土地来源", "新增"),
            industry=data.get("行业分类", "其他"),
        )
        return jsonify({
            "ok": True,
            "总价_万元": round(total, 2),
            "单价_万元每平米": round(unit, 4),
        })
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"土地估值模型网站已启动: http://127.0.0.1:{port}")
    app.run(host="127.0.0.1", port=port, debug=False)
