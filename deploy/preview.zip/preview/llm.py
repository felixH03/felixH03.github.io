# -*- coding: utf-8 -*-
"""大模型调用模块：通过 OpenAI 兼容接口调用 DeepSeek（或任意兼容服务）。"""
import json
import re
import requests
import config


class LLMError(RuntimeError):
    """大模型调用失败时抛出。"""


def _headers():
    if not config.DEEPSEEK_API_KEY:
        raise LLMError(
            "尚未配置大模型 API Key。请在项目根目录的 .env 文件中填写 "
            "DEEPSEEK_API_KEY=你的Key（可参考 .env.example）。"
        )
    return {
        "Authorization": f"Bearer {config.DEEPSEEK_API_KEY}",
        "Content-Type": "application/json",
    }


def chat(system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str:
    """
    调用聊天补全接口。
    temperature 取低值，保证预审报告风格稳定、措辞克制。
    """
    url = f"{config.DEEPSEEK_BASE_URL}/chat/completions"
    payload = {
        "model": config.DEEPSEEK_MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": temperature,
        "stream": False,
    }

    try:
        resp = requests.post(url, json=payload, headers=_headers(), timeout=600)
        resp.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise LLMError(f"大模型接口请求失败：{e}") from e

    data = resp.json()
    try:
        return data["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError) as e:
        raise LLMError(f"大模型返回内容无法解析：{data}") from e


def chat_json(system_prompt: str, user_prompt: str, temperature: float = 0.2,
              retries: int = 2) -> dict:
    """
    调用大模型并要求其输出 JSON 对象，解析后返回 dict。
    若首次输出被 markdown 围栏包裹或解析失败，自动剥离围栏并重试。
    """
    last_err = None
    for _ in range(retries + 1):
        content = chat(system_prompt, user_prompt, temperature=temperature)
        text = content.strip()

        # 剥离 ```json ... ``` / ``` ... ``` 围栏
        if text.startswith("```"):
            text = re.sub(r"^```[a-zA-Z]*\s*", "", text)
            text = re.sub(r"\s*```$", "", text)

        try:
            obj = json.loads(text)
            if isinstance(obj, dict):
                return obj
            raise ValueError("顶层不是 JSON 对象")
        except (json.JSONDecodeError, ValueError) as e:
            last_err = e

    raise LLMError(f"大模型返回的不是有效 JSON，已重试仍无法解析：{last_err}")
