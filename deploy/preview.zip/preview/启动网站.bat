@echo off
rem ============================================
rem  自动预审网站 — 双击启动脚本
rem  启动后请在浏览器打开 http://127.0.0.1:5000
rem  关闭本窗口 = 停止网站
rem ============================================

rem 切换到脚本所在目录（双击运行时所在路径）
cd /d "%~dp0"

rem 切换到 UTF-8 编码，确保中文提示正常显示
chcp 65001 >nul

title 自动预审网站

echo.
echo ============================================
echo   自动预审网站 正在启动...
echo.
echo   启动后请在浏览器打开:  http://127.0.0.1:5000
echo   关闭本窗口 = 停止网站
echo ============================================
echo.

rem 检查虚拟环境是否存在
if not exist ".venv\Scripts\python.exe" (
    echo [错误] 未找到 .venv\Scripts\python.exe
    echo 请确认虚拟环境已创建后再试。
    pause
    exit /b 1
)

rem 启动网站（前台运行，关闭窗口即停止）
.venv\Scripts\python.exe app.py

echo.
echo [提示] 网站已停止，上方若有报错信息请留意。
pause
