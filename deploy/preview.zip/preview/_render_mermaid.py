# -*- coding: utf-8 -*-
"""临时脚本:调用 mermaid.ink 将 mermaid 流程图渲染为 PNG(尝试多种编码)。"""
import json
import zlib
import base64
import sys
import urllib.request
import urllib.parse

code = """graph LR
    A[浏览器 127.0.0.1:5000] --> B[Flask 本地服务器 app.py]
    B --> C[上传 docx/pdf → 解析文本]
    C --> D[router 路由选 skill]
    D --> E[构造 Prompt]
    E --> F[DeepSeek 云端 API api.deepseek.com]
    F --> G[返回预审报告]
    G --> H[docgen 生成 Word 下载]"""

out = sys.argv[1] if len(sys.argv) > 1 else "diagram.png"

def try_fetch(url, label):
    print(f"[try] {label}")
    print(f"  url: {url[:130]}")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            content = r.read()
            print(f"  -> OK {r.status} ({len(content)} bytes)")
            return content
    except urllib.error.HTTPError as e:
        body = e.read()[:400].decode("utf-8", "replace")
        print(f"  -> HTTP {e.code}: {body}")
        return None

payload = json.dumps({"code": code, "mermaid": {"theme": "default"}}, ensure_ascii=False).encode("utf-8")

# 方案1: 未压缩 JSON base64(标准)
b1 = base64.b64encode(payload).decode("ascii")
content = try_fetch(f"https://mermaid.ink/img/{b1}", "plain base64")
if content:
    open(out, "wb").write(content); print(f"saved {out} via plain base64"); sys.exit(0)

# 方案2: pako (zlib) 压缩 base64(标准)
compressed = zlib.compress(payload, 9)
b2 = base64.b64encode(compressed).decode("ascii")
content = try_fetch(f"https://mermaid.ink/img/pako:{b2}", "pako base64")
if content:
    open(out, "wb").write(content); print(f"saved {out} via pako"); sys.exit(0)

# 方案3: 对 base64 做 URL 编码后请求(含 / + 的字符被转义)
b3 = urllib.parse.quote(b1, safe="")
content = try_fetch(f"https://mermaid.ink/img/{b3}", "urlencoded plain base64")
if content:
    open(out, "wb").write(content); print(f"saved {out} via urlencoded"); sys.exit(0)

# 方案4: pako + urlencode
b4 = urllib.parse.quote(b2, safe="")
content = try_fetch(f"https://mermaid.ink/img/pako:{b4}", "urlencoded pako base64")
if content:
    open(out, "wb").write(content); print(f"saved {out} via urlencoded pako"); sys.exit(0)

print("ALL METHODS FAILED")
sys.exit(1)
