# -*- coding: utf-8 -*-
"""
自动预审网站 — 主程序
流程：网页上传 → 解析文本 → 自动路由（抚州/江西）→ 读取对应 skill 生成 Prompt → 调用大模型 → 生成 Word 报告并下载。
"""
import os
import re
import uuid
import json
import datetime
from flask import Flask, render_template, request, send_from_directory, abort, jsonify

import config
import router
import llm
import docgen
import splitgen

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = config.MAX_CONTENT_LENGTH
# 开发便利：模板改动自动生效，静态文件不做长缓存
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0

os.makedirs(config.UPLOAD_DIR, exist_ok=True)
os.makedirs(config.OUTPUT_DIR, exist_ok=True)

SYSTEM_TEMPLATE = """你是资深数字化项目预审专家。请严格按照下方「预审规范」对用户提供的项目建议书/技术方案进行预审，并输出预审报告。

===== 预审规范 =====
{skill}

===== 输出要求 =====
严格按照以下 Markdown 结构输出，不要输出任何额外说明、不要加序号、不要写总结语、不要评价整体质量：

# 【项目完整名称】预审报告

委托单位：【原文中的委托/建设单位；不明确则写“委托单位：】单位：【可省略】】
时间：{today}（直接使用，不要改动）

## 项目概述

项目名称：【完整名称】
项目建设单位：【XX局/厅】
项目预算：【XXX万元】
项目性质：【新建/升级改造/运行维护】
项目【建设/运维】内容：
（一）【模块1】。【简要描述，摘自原文】
（二）【模块2】。【简要描述，摘自原文】

（注：项目概述一律摘自原文，不添加任何主观评价）

## 预审依据

1.《…》
2.《…》
（依据预审规范中规定的固定条款，一字不差）

## 预审建议

- "章节标题"中…，建议…。
（严格遵循预审规范的语言风格铁律：一句一议、每条引用原文章节定位、不加序号、不加分类标题、不写“综上所述”，措辞用“建议”而非“应该/必须”）

===== 硬性要求（必须遵守） =====
1. 预审建议控制在 8~15 条，宁缺毋滥，不凑数。
2. 每条建议都必须针对原文中真实存在的具体问题，且能在《评审要点》中找到依据；原文没有问题的地方不要写建议。
3. 禁止罗列无针对性的通用套话（如“补充风险管理”“补充质量管理体系”“补充成本控制措施”等空泛项）。
4. 同类问题合并为一条，不得重复。"""


def build_system_prompt(skill_text: str) -> str:
    today = datetime.date.today()
    year_month = f"{today.year}年{today.month}月"
    return SYSTEM_TEMPLATE.format(skill=skill_text, today=year_month)


SPLIT_SYSTEM_TEMPLATE = """你是资深软件功能点分析（FPA）专家。请严格按照下方「软件功能点拆分规则」对待拆文档进行功能点拆分，输出结构化的功能点清单。

===== 拆分规则 =====
{skill}

===== 输入文档处理方式 =====
- 若上传的是完整项目建议书/需求规格文档：先从原文中抽取所有可独立触发、可独立计量的功能点，再按规则拆分成层级结构。
- 若上传的已经是功能点清单：直接按规则完成层级归类与功能类型赋予。
- 一个「保存/提交/确认」按钮算 1 个功能点；同一实体的增/删/改/查必须拆分为独立功能点。
- 功能点名称遵循「动词+宾语」或「宾语+动词」，4~16 字，全系统唯一。
- 严格按规则 1.4 的停止深化判据判断是否可再分，输出必须到最终功能点（叶子节点）。

===== 输出要求 =====
只输出一个 JSON 对象，不要输出任何其他文字、注释或 markdown 围栏。JSON 结构如下：

{{
  "system_name": "系统名称（从原文提取；不明确则填“未命名系统”）",
  "system_type": "系统类型（交互型/数据处理型/设备管理型/混合型）",
  "function_points": [
    {{
      "system": "子系统名称（无子系统则填系统名）",
      "level1": "一级模块名称",
      "level2": "二级模块名称（无则填空字符串）",
      "level3": "三级模块名称（无则填空字符串）",
      "level4": "四级模块名称（无则填空字符串）",
      "name": "功能点名称",
      "type": "EI 或 EQ 或 EO 或 EIF 或 ILF",
      "remark": "备注（可为空字符串）"
    }}
  ]
}}

硬性要求：
1. function_points 中每条记录必须对应一个最终功能点（叶子节点），不可再分。
2. 层级名称要体现规则 1 的切分视角（用户功能域 / 数据加工流 / 设备数据域）。
3. 功能类型严格按规则 3 的动词-类型映射矩阵与边界判定赋予。
4. 功能点总数在 500 以内时，标准深度为 3 层（子系统→一级→二级→功能点），仅在满足规则 1.3 条件时才出现三级/四级。
5. 若某 ILF 属于“内部逻辑已存在，不重复计数”，请在 remark 中注明。"""


def build_split_prompt(skill_text: str) -> str:
    return SPLIT_SYSTEM_TEMPLATE.format(skill=skill_text)


def extract_text(path: str) -> str:
    """从 .docx / .pdf / .xlsx / .xls 提取纯文本（含表格内容）。"""
    ext = os.path.splitext(path)[1].lower()

    if ext == ".docx":
        from docx import Document
        doc = Document(path)
        parts = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
        for table in doc.tables:
            for row in table.rows:
                cells = [c.text.strip() for c in row.cells]
                parts.append(" | ".join(cells))
        return "\n".join(parts)

    if ext == ".pdf":
        import pdfplumber
        texts = []
        with pdfplumber.open(path) as pdf:
            for page in pdf.pages:
                texts.append(page.extract_text() or "")
        return "\n".join(texts)

    if ext in (".xlsx", ".xls"):
        return _extract_excel(path, ext)

    raise ValueError("不支持的文件类型，仅支持 .docx / .pdf / .xlsx / .xls")


def _extract_excel(path: str, ext: str) -> str:
    """提取 Excel 内容：每个工作表一行标题，单元格用 | 分隔。"""
    parts = []

    if ext == ".xlsx":
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        for ws in wb.worksheets:
            parts.append(f"[工作表：{ws.title}]")
            for row in ws.iter_rows(values_only=True):
                cells = [_cell_text(c) for c in row]
                cells = [c for c in cells if c]
                if cells:
                    parts.append(" | ".join(cells))
        return "\n".join(parts)

    import xlrd
    wb = xlrd.open_workbook(path)
    for sheet in wb.sheets():
        parts.append(f"[工作表：{sheet.name}]")
        for r in range(sheet.nrows):
            cells = [_cell_text(sheet.cell_value(r, c)) for c in range(sheet.ncols)]
            cells = [c for c in cells if c]
            if cells:
                parts.append(" | ".join(cells))
    return "\n".join(parts)


def _cell_text(value) -> str:
    """把单元格值转成文本（浮点整数值去掉 .0）。"""
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/health")
def health():
    return {"status": "ok"}


@app.route("/upload", methods=["POST"])
def upload():
    file = request.files.get("file")
    if not file or not file.filename:
        return jsonify(error="未选择文件，请重新上传。")

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in config.ALLOWED_EXTENSIONS:
        return jsonify(error=f"不支持的文件类型“{ext or '(无扩展名)'}”，仅支持 Word（.docx）和 PDF（.pdf）。")

    token = uuid.uuid4().hex[:12]
    saved_path = os.path.join(config.UPLOAD_DIR, f"{token}{ext}")
    file.save(saved_path)

    # 1. 解析文本
    try:
        text = extract_text(saved_path)
    except Exception as e:
        return jsonify(error=f"文件解析失败：{e}")
    finally:
        try:
            os.remove(saved_path)
        except OSError:
            pass

    if not text or len(text.strip()) < 50:
        return jsonify(error="未能从文件中提取到有效文本，请确认文件是可编辑的 Word/PDF（扫描件需先 OCR）。")

    # 2. 自动路由：抚州 → 抚州 skill；其他 → 江西 skill
    region = router.detect_region(text, file.filename)
    if region == "yuyao":
        return jsonify(error="检测到该项目属于余姚/浙江范围，暂未纳入本工作流（当前仅支持抚州及江西省内项目）。")

    # 3. 读取对应 skill 作为预审规范
    skill_text = router.load_skill_text(region)
    system_prompt = build_system_prompt(skill_text)

    # 4. 调用大模型生成预审报告
    user_prompt = f"待审项目建议书/技术方案全文如下：\n\n{text}"
    try:
        report_md = llm.chat(system_prompt, user_prompt)
    except llm.LLMError as e:
        return jsonify(error=str(e))
    except Exception as e:
        return jsonify(error=f"生成报告失败：{e}")

    # 5. 生成 Word 报告，并保存报告文本与元信息（供独立结果页读取）
    out_name = f"预审报告_{token}.docx"
    out_path = os.path.join(config.OUTPUT_DIR, out_name)
    try:
        docgen.build_report(report_md, out_path, project_name=file.filename)
    except Exception as e:
        return jsonify(error=f"生成 Word 报告失败：{e}")

    with open(os.path.join(config.OUTPUT_DIR, f"预审报告_{token}.md"), "w", encoding="utf-8") as f:
        f.write(report_md)
    meta = {"region_name": router.region_display_name(region), "filename": file.filename}
    with open(os.path.join(config.OUTPUT_DIR, f"预审报告_{token}.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False)

    # 跳转到独立的结果页地址（PRG 模式），避免结果覆盖在首页地址上
    return jsonify(redirect=f"/result/{token}")


@app.route("/result/<token>")
def result(token):
    """独立的结果页：按 token 读取已生成的报告并展示。"""
    if not re.fullmatch(r"[A-Za-z0-9_-]{8,}", token):
        abort(404)
    md_path = os.path.join(config.OUTPUT_DIR, f"预审报告_{token}.md")
    json_path = os.path.join(config.OUTPUT_DIR, f"预审报告_{token}.json")
    docx_name = f"预审报告_{token}.docx"
    if not (os.path.exists(md_path) and os.path.exists(json_path)
            and os.path.exists(os.path.join(config.OUTPUT_DIR, docx_name))):
        abort(404)

    with open(md_path, "r", encoding="utf-8") as f:
        report_md = f.read()
    with open(json_path, "r", encoding="utf-8") as f:
        meta = json.load(f)

    return render_template("result.html",
                           region_name=meta.get("region_name", ""),
                           filename=meta.get("filename", ""),
                           report_md=report_md,
                           download=docx_name)


@app.route("/upload_split", methods=["POST"])
def upload_split():
    """软件功能点拆分：上传 → 解析 → 按规则拆分 → 生成 Excel。"""
    file = request.files.get("file")
    if not file or not file.filename:
        return jsonify(error="未选择文件，请重新上传。")

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in config.SPLIT_ALLOWED_EXTENSIONS:
        return jsonify(error=f"不支持的文件类型“{ext or '(无扩展名)'}”，拆分模式支持 Word（.docx）、PDF（.pdf）和 Excel（.xlsx/.xls）。")

    token = uuid.uuid4().hex[:12]
    saved_path = os.path.join(config.UPLOAD_DIR, f"{token}{ext}")
    file.save(saved_path)

    # 1. 解析文本
    try:
        text = extract_text(saved_path)
    except Exception as e:
        return jsonify(error=f"文件解析失败：{e}")
    finally:
        try:
            os.remove(saved_path)
        except OSError:
            pass

    if not text or len(text.strip()) < 50:
        return jsonify(error="未能从文件中提取到有效文本，请确认文件是可编辑的 Word/PDF/Excel（扫描件需先 OCR）。")

    # 2. 读取拆分 skill 作为规则
    skill_text = router.load_skill_text("split")
    system_prompt = build_split_prompt(skill_text)

    # 3. 调用大模型生成结构化拆分结果
    user_prompt = f"待拆分的项目文档全文如下：\n\n{text}"
    try:
        data = llm.chat_json(system_prompt, user_prompt)
    except llm.LLMError as e:
        return jsonify(error=str(e))
    except Exception as e:
        return jsonify(error=f"功能点拆分失败：{e}")

    rows, stats = splitgen.flatten(data)
    if not rows:
        return jsonify(error="未能从文档中识别出可拆分的功能点，请确认文档内容是否完整。")

    # 4. 生成 Excel 拆分表
    xlsx_name = f"功能点拆分_{token}.xlsx"
    xlsx_path = os.path.join(config.OUTPUT_DIR, xlsx_name)
    try:
        splitgen.build_excel(data, xlsx_path, project_name=file.filename)
    except Exception as e:
        return jsonify(error=f"生成 Excel 拆分表失败：{e}")

    # 5. 保存原始拆分结果（供独立结果页展示）
    payload = {"filename": file.filename, "data": data}
    with open(os.path.join(config.OUTPUT_DIR, f"功能点拆分_{token}.json"), "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)

    return jsonify(redirect=f"/split_result/{token}")


@app.route("/split_result/<token>")
def split_result(token):
    """功能点拆分结果页：按 token 读取已生成的拆分结果并展示。"""
    if not re.fullmatch(r"[A-Za-z0-9_-]{8,}", token):
        abort(404)
    json_path = os.path.join(config.OUTPUT_DIR, f"功能点拆分_{token}.json")
    xlsx_name = f"功能点拆分_{token}.xlsx"
    if not (os.path.exists(json_path)
            and os.path.exists(os.path.join(config.OUTPUT_DIR, xlsx_name))):
        abort(404)

    with open(json_path, "r", encoding="utf-8") as f:
        payload = json.load(f)
    rows, stats = splitgen.flatten(payload.get("data") or {})

    return render_template("split_result.html",
                           filename=payload.get("filename", ""),
                           rows=rows,
                           stats=stats,
                           download=xlsx_name)


@app.route("/download_split/<filename>")
def download_split(filename):
    if not re.fullmatch(r"[A-Za-z0-9_\u4e00-\u9fff\-]+\.xlsx", filename):
        abort(404)
    return send_from_directory(config.OUTPUT_DIR, filename, as_attachment=True)


@app.route("/download/<filename>")
def download(filename):
    if not re.fullmatch(r"[A-Za-z0-9_\u4e00-\u9fff\-]+\.docx", filename):
        abort(404)
    return send_from_directory(config.OUTPUT_DIR, filename, as_attachment=True)


if __name__ == "__main__":
    print("=" * 56)
    print("  自动预审网站已启动")
    print("  请在浏览器打开:  http://127.0.0.1:5000")
    print("=" * 56)
    app.run(host="127.0.0.1", port=5000, debug=False)
