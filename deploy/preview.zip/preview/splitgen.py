# -*- coding: utf-8 -*-
"""
软件功能点拆分 Excel 生成模块。
输入：大模型返回的拆分 JSON（splitgen.flatten 需要的数据结构）。
输出：带层级合并、类型统计的 .xlsx 功能点拆分表。
"""
import datetime
from collections import Counter

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

COLUMNS = ["子系统", "一级模块", "二级模块", "三级模块", "四级模块", "功能点名称", "功能类型", "备注"]
MERGE_COLS = ["system", "level1", "level2", "level3", "level4"]
TYPE_ORDER = ["EI", "EQ", "EO", "ILF", "EIF"]

# ---------- 样式 ----------
_HEADER_FILL = PatternFill("solid", fgColor="1F4E9C")
_HEADER_FONT = Font(name="微软雅黑", size=11, bold=True, color="FFFFFF")
_TITLE_FONT = Font(name="微软雅黑", size=14, bold=True)
_INFO_FONT = Font(name="微软雅黑", size=10, color="6B7688")
_BODY_FONT = Font(name="微软雅黑", size=10)
_STAT_FONT = Font(name="微软雅黑", size=10, bold=True)
_STAT_FILL = PatternFill("solid", fgColor="FDF3E0")
_THIN = Side(style="thin", color="D4DEEF")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)
_CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
_LEFT = Alignment(horizontal="left", vertical="center", wrap_text=True)

_TYPE_FILLS = {
    "EI": PatternFill("solid", fgColor="E3F0FF"),
    "EQ": PatternFill("solid", fgColor="EAF7E9"),
    "EO": PatternFill("solid", fgColor="FFF4DC"),
    "EIF": PatternFill("solid", fgColor="F3E9FA"),
    "ILF": PatternFill("solid", fgColor="FDECEA"),
}

_COL_WIDTHS = [18, 18, 18, 18, 18, 26, 10, 28]


def flatten(data: dict) -> tuple[list[dict], dict]:
    """把大模型 JSON 拆成表格行 + 统计信息，供 Excel 与结果页共用。"""
    fps = data.get("function_points") or []
    rows = []
    for fp in fps:
        if not isinstance(fp, dict):
            continue
        name = (fp.get("name") or "").strip()
        if not name:
            continue
        rows.append({
            "system": (fp.get("system") or "").strip(),
            "level1": (fp.get("level1") or "").strip(),
            "level2": (fp.get("level2") or "").strip(),
            "level3": (fp.get("level3") or "").strip(),
            "level4": (fp.get("level4") or "").strip(),
            "name": name,
            "type": (fp.get("type") or "").strip().upper(),
            "remark": (fp.get("remark") or "").strip(),
        })

    counter = Counter(r["type"] for r in rows if r["type"] in TYPE_ORDER)
    stats = {
        "system_name": (data.get("system_name") or "").strip(),
        "system_type": (data.get("system_type") or "").strip(),
        "total": len(rows),
        "counts": {t: counter.get(t, 0) for t in TYPE_ORDER},
    }
    return rows, stats


def _fill_cell(cell, value, font, align, fill=None, border=None):
    cell.value = value
    cell.font = font
    cell.alignment = align
    if fill:
        cell.fill = fill
    if border:
        cell.border = border


def build_excel(data: dict, out_path: str, project_name: str = "功能点清单") -> dict:
    """生成功能点拆分 Excel，返回统计信息。"""
    rows, stats = flatten(data)
    wb = Workbook()
    ws = wb.active
    ws.title = "功能点拆分"

    n_cols = len(COLUMNS)
    last_col = chr(ord("A") + n_cols - 1)

    # 1. 标题
    title = f"{stats['system_name'] or '未命名系统'} — 功能点拆分表"
    ws.merge_cells(f"A1:{last_col}1")
    _fill_cell(ws["A1"], title, _TITLE_FONT, _CENTER)

    # 2. 信息行
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    info = f"原文件：{project_name}    拆分时间：{now}    功能点合计：{stats['total']} 个"
    ws.merge_cells(f"A2:{last_col}2")
    _fill_cell(ws["A2"], info, _INFO_FONT, _LEFT)

    # 3. 表头
    header_row = 3
    for c, name in enumerate(COLUMNS, start=1):
        cell = ws.cell(header_row, c)
        _fill_cell(cell, name, _HEADER_FONT, _CENTER, _HEADER_FILL, _BORDER)

    # 4. 数据行（层级列连续相同值合并，符合“只在首行填写”）
    start = header_row + 1
    for r, row in enumerate(rows, start=start):
        type_val = row["type"] if row["type"] in TYPE_ORDER else "其他"
        values = [row["system"], row["level1"], row["level2"],
                  row["level3"], row["level4"], row["name"], type_val, row["remark"]]
        for c, v in enumerate(values, start=1):
            cell = ws.cell(r, c)
            align = _CENTER if c in (7,) else _LEFT
            fill = _TYPE_FILLS.get(row["type"])
            _fill_cell(cell, v if v else "", _BODY_FONT, align, fill, _BORDER)

    # 层级合并
    for ci in range(1, len(MERGE_COLS) + 1):
        _merge_runs(ws, ci, start, start + len(rows) - 1)

    # 5. 类型统计
    stat_row = start + len(rows)
    ws.merge_cells(f"A{stat_row}:{chr(ord('A') + 5 - 1)}{stat_row}")
    _fill_cell(ws.cell(stat_row, 1), "功能类型统计", _STAT_FONT, _CENTER, _STAT_FILL, _BORDER)
    col = 7
    for t in TYPE_ORDER:
        cell = ws.cell(stat_row, col)
        _fill_cell(cell, f"{t} {stats['counts'][t]}", _STAT_FONT, _CENTER, _STAT_FILL, _BORDER)
        col += 1

    # 列宽
    for i, w in enumerate(_COL_WIDTHS, start=1):
        ws.column_dimensions[chr(ord("A") + i - 1)].width = w
    ws.freeze_panes = f"A{header_row + 1}"
    ws.row_dimensions[1].height = 26

    wb.save(out_path)
    return stats


def _merge_runs(ws, col, start, end):
    """对某一列，把连续取值相同的行合并单元格（保留首格值）。"""
    r = start
    while r <= end:
        v = ws.cell(r, col).value
        if not v:  # 空层级不合并
            r += 1
            continue
        run_end = r
        while run_end + 1 <= end and ws.cell(run_end + 1, col).value == v:
            run_end += 1
        if run_end > r:
            ws.merge_cells(start_row=r, start_column=col, end_row=run_end, end_column=col)
            # 合并区域所有单元格补边框（openpyxl 合并后边框会丢失）
            for rr in range(r, run_end + 1):
                ws.cell(rr, col).border = _BORDER
            ws.cell(r, col).alignment = _LEFT
        r = run_end + 1
