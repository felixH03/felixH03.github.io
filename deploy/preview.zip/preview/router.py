# -*- coding: utf-8 -*-
"""地区路由：根据待审文件的文件名与正文，自动判断归属哪个 skill。"""

import os
import re
import config


def detect_region(text: str, filename: str = "") -> str:
    """
    判断项目归属地，返回 skill 键名：
      - "fuzhou"  : 抚州项目 → 使用抚州 skill
      - "jiangxi" : 江西省内其他地市 → 使用江西 skill
      - "yuyao"   : 余姚/浙江项目 → 暂不支持（用户要求先不管）
    判断优先级：文件名 > 正文关键词 > 政策文件引用。
    """
    name = (filename or "")
    body = (text or "")

    # 1) 抚州：文件名或正文中出现“抚州”，或引用《抚州市…》文件
    if "抚州" in name or "抚州" in body:
        return "fuzhou"
    if re.search(r"《抚州(市)?[^》]*》", body):
        return "fuzhou"

    # 2) 余姚 / 浙江：提示暂不支持（用户明确说暂时不纳入本工作流）
    if "余姚" in name or "余姚" in body or "浙江" in body:
        return "yuyao"

    # 3) 兜底：江西省内其他地市（赣州、南昌、九江、上饶等）
    return "jiangxi"


def region_display_name(region: str) -> str:
    """路由结果的中文展示名。"""
    return {
        "fuzhou": "抚州 skill",
        "jiangxi": "江西 skill（全省通用）",
        "yuyao": "余姚 skill（暂未纳入）",
    }.get(region, region)


def skill_file_path(region: str) -> str:
    """返回对应 skill .md 的绝对路径。"""
    fname = config.SKILL_FILES.get(region)
    if not fname:
        raise ValueError(f"未知地区: {region}")
    return os.path.join(config.SKILL_DIR, fname)


def load_skill_text(region: str) -> str:
    """
    读取 skill .md 的内容作为 Prompt 规范。
    去掉 YAML frontmatter（开头两个 --- 之间的部分）。
    """
    path = skill_file_path(region)
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    # 剥离 YAML frontmatter
    if content.startswith("---"):
        parts = content.split("---", 2)
        if len(parts) == 3:
            content = parts[2].lstrip("\n")
    return content.strip()
