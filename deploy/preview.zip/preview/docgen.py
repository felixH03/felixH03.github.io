# -*- coding: utf-8 -*-
"""
Word 版预审报告生成模块。
严格遵循 skill 中的「Word 文档行文格式规范」：
  - A4，页边距 上/下 2.54cm、左/右 3.17cm，页码底部居中（封面不显示）
  - 主标题（#）        ：黑体 22pt 加粗 居中
  - 一级标题（##）      ：黑体 16pt 居中（不加粗）
  - 正文              ：仿宋_GB2312 14pt，行距 28pt 固定，首行缩进 2 字符
  - 预审依据列表（数字） ：仿宋_GB2312 14pt，行距 24pt 固定，段前 10.5pt
  - 预审建议条目（-）   ：仿宋_GB2312 14pt，行距 28pt 固定，悬挂缩进 2 字符
  - 委托单位/单位/时间  ：黑体 16pt 加粗 居中
  - 英文/数字          ：Times New Roman
"""
import re
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

# ---------- 基础工具 ----------

def _set_run_font(run, cn_font, size_pt, bold=False):
    run.font.name = "Times New Roman"
    run.font.size = Pt(size_pt)
    run.font.bold = bold
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:ascii"), "Times New Roman")
    rfonts.set(qn("w:hAnsi"), "Times New Roman")
    rfonts.set(qn("w:eastAsia"), cn_font)


def _set_exact_line(p, pt):
    pf = p.paragraph_format
    pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    pf.line_spacing = Pt(pt)


def _set_first_line_chars(p, chars=2):
    ppr = p._p.get_or_add_pPr()
    ind = ppr.get_or_add_ind()
    ind.set(qn("w:firstLineChars"), str(chars * 100))


def _set_hanging_chars(p, chars=2):
    ppr = p._p.get_or_add_pPr()
    ind = ppr.get_or_add_ind()
    ind.set(qn("w:hangingChars"), str(chars * 100))


def _add_page_number(section):
    """页脚底部居中插入 PAGE 域；首页不同（封面不显示页码）。"""
    section.different_first_page_header_footer = True
    footer = section.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    fld_begin = OxmlElement("w:fldChar"); fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText"); instr.set(qn("xml:space"), "preserve"); instr.text = "PAGE"
    fld_end = OxmlElement("w:fldChar"); fld_end.set(qn("w:fldCharType"), "end")
    run._r.append(fld_begin)
    run._r.append(instr)
    run._r.append(fld_end)
    _set_run_font(run, "仿宋_GB2312", 14)


# ---------- 段落写入 ----------

def _add_paragraph(doc, text, cn_font, size, bold, align,
                   line_pt=None, space_before=0, space_after=0,
                   first_line_chars=0, hanging_chars=0):
    p = doc.add_paragraph()
    p.alignment = align
    pf = p.paragraph_format
    if line_pt:
        _set_exact_line(p, line_pt)
    pf.space_before = Pt(space_before)
    pf.space_after = Pt(space_after)
    if first_line_chars:
        _set_first_line_chars(p, first_line_chars)
    if hanging_chars:
        _set_hanging_chars(p, hanging_chars)
    run = p.add_run(text)
    _set_run_font(run, cn_font, size, bold)
    return p


# ---------- 主流程 ----------

def _normalize_text(s: str) -> str:
    """去掉 markdown 强调/链接符号，保留纯文本。"""
    s = re.sub(r"([*_`])", "", s)
    s = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", s)
    return s


def build_report(md_text: str, out_path: str, project_name: str = "数字化项目") -> None:
    doc = Document()

    # 页面设置
    section = doc.sections[0]
    section.page_width = Cm(21.0)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(3.17)
    section.right_margin = Cm(3.17)
    _add_page_number(section)

    # 模块跟踪：当前处于哪个一级模块（决定列表行距）
    current_module = "概述"

    for raw in md_text.splitlines():
        line = raw.rstrip()
        stripped = line.strip()
        if not stripped:
            continue

        # 代码围栏行直接跳过
        if stripped.startswith("```"):
            continue

        # 主标题
        if stripped.startswith("# ") and not stripped.startswith("## "):
            title = _normalize_text(stripped[2:].strip())
            _add_paragraph(doc, title, "黑体", 22, True,
                           WD_ALIGN_PARAGRAPH.CENTER, line_pt=None,
                           space_after=29)
            continue

        # 一级标题（##）
        if stripped.startswith("## "):
            heading = _normalize_text(stripped[3:].strip())
            current_module = ("依据" if "预审依据" in heading else
                              "建议" if "预审建议" in heading else
                              "概述")
            _add_paragraph(doc, heading, "黑体", 16, False,
                           WD_ALIGN_PARAGRAPH.CENTER, line_pt=28)
            continue

        # 二级标题（###）——黑体 15pt 左对齐
        if stripped.startswith("### "):
            heading = _normalize_text(stripped[4:].strip())
            _add_paragraph(doc, heading, "黑体", 15, False,
                           WD_ALIGN_PARAGRAPH.LEFT, line_pt=28)
            continue

        # 委托单位/单位/时间：黑体 16pt 加粗居中
        if re.match(r"^(委托单位|单位|时间)[:：]", stripped):
            _add_paragraph(doc, _normalize_text(stripped), "黑体", 16, True,
                           WD_ALIGN_PARAGRAPH.CENTER, line_pt=None,
                           space_after=6)
            continue

        # 数字列表（预审依据）：24pt 固定行距，段前 10.5pt
        if re.match(r"^\d+[.、．]", stripped):
            _add_paragraph(doc, _normalize_text(stripped), "仿宋_GB2312", 14, False,
                           WD_ALIGN_PARAGRAPH.JUSTIFY,
                           line_pt=(24 if current_module == "依据" else 28),
                           space_before=(10.5 if current_module == "依据" else 0),
                           first_line_chars=0)
            continue

        # 无序列表（预审建议）：悬挂缩进 2 字符
        if stripped.startswith("- ") or stripped.startswith("* "):
            item = _normalize_text(stripped[2:].strip())
            _add_paragraph(doc, item, "仿宋_GB2312", 14, False,
                           WD_ALIGN_PARAGRAPH.JUSTIFY, line_pt=28,
                           hanging_chars=2)
            continue

        # 普通正文：首行缩进 2 字符
        _add_paragraph(doc, _normalize_text(stripped), "仿宋_GB2312", 14, False,
                       WD_ALIGN_PARAGRAPH.JUSTIFY, line_pt=28,
                       first_line_chars=2)

    doc.save(out_path)
