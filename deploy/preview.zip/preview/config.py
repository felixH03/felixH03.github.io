# -*- coding: utf-8 -*-
"""全局配置：读取 .env 环境变量（API Key 等），并定位 skill 模板目录。"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.join(BASE_DIR, "skill")          # 存放三个 skill .md 的目录
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")       # 上传的待审文件
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")       # 生成的预审报告 Word

# 允许上传的文件类型（预审模式）
ALLOWED_EXTENSIONS = {".docx", ".pdf"}

# 软件功能点拆分额外允许 Excel（.xlsx / .xls）
SPLIT_ALLOWED_EXTENSIONS = {".docx", ".pdf", ".xlsx", ".xls"}

# 最大上传大小：20MB
MAX_CONTENT_LENGTH = 20 * 1024 * 1024


def _load_env():
    """手动解析 .env 文件（避免额外依赖 python-dotenv）。"""
    env_path = os.path.join(BASE_DIR, ".env")
    if os.path.exists(env_path):
        with open(env_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip())


_load_env()

# 大模型配置（DeepSeek，OpenAI 兼容接口）
DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY", "").strip()
DEEPSEEK_BASE_URL = os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com").rstrip("/")
DEEPSEEK_MODEL = os.environ.get("DEEPSEEK_MODEL", "deepseek-chat").strip()

# 各 skill 文件在 SKILL_DIR 下的文件名
SKILL_FILES = {
    "fuzhou": "抚州数字化项目预审报告编写.md",
    "jiangxi": "江西省数字化项目预审报告编写.md",
    "yuyao": "余姚市信息化项目初审意见编写.md",
    "split": "软件功能点拆分规则.md",
}
